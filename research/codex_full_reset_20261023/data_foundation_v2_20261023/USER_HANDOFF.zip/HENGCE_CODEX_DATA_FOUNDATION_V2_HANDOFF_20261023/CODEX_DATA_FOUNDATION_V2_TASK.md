# HENGCE — Codex Data Foundation V2 continuation

## Authorization and mission

Continue from the exact V1 evidence head. This is a **research-only data-readiness stage**, not a profitability/model-search stage.

Primary mission:

> Resolve the corporate-action entitlement, security-identity, delivery/payment, and direction-aware execution evidence gaps that currently keep adjusted-return research at `BLOCKED_DATA_READINESS`.

Do not retroactively rescue, rewrite, delete, or reclassify any of the 8,529 prior model evaluations. Do not promote any old apparent winner.

## Frozen parent

- Parent research head: `0c24f9795e36b52e28eafed186eee5591ec93353`
- Registered V2 handoff commit: `593652df3e414b223eea0d568299084cf5c85c52`
- Frozen corpus base: `05bf0e35fb6a88473fd4f947952ef1b6875d3f88`
- Cumulative prior model evaluations: `8529`
- New model-evaluation budget for this stage: **0**
- Production authority: **none**

Do not silently rebase onto moving `main`.

## Workstream A — classify all retained PIT electronics actions

Start from the already retained **1,151 exact-PIT electronics events**.

For every event classify at minimum:

- cash dividend
- stock dividend / free shares
- rights / paid subscription
- capital reduction — cash return
- capital reduction — no cash / loss absorption
- split / reverse split / share conversion
- merger / delisting / relisting / identity transition
- suspension/resumption associated with action
- mixed action
- unknown / insufficient schema

Never infer missing numeric terms as zero.

## Workstream B — entitlement ledger

Build an append-only entitlement ledger. Include, where officially proven:

- old security identity
- new security identity
- effective/ex date
- last trading date before action
- resumption/listing date
- cash entitlement per old share
- free/new shares per old share
- paid-subscription shares per old share
- subscription price
- subscription/payment deadline
- cash payment date
- new-share delivery/listing/saleable date
- fractional-share treatment
- official source and source hash
- publication/printed date
- first-seen/revision lineage only when actually proven
- status: PROVEN / PARTIAL / UNKNOWN / CONFLICT

Do not assume immediate reinvestment or same-day saleability.

## Workstream C — security identity continuity

Build explicit old->new identity transitions for every event affecting:

- ticker
- listed instrument identity
- share count
- conversion / split / merger / relisting continuity

No current-security-master substitution for historical identity.

Unknown continuity blocks dependent PnL.

## Workstream D — historical impact map

Map corporate-action/suspension events onto every historical research trade/outcome window used in the 8,529 retained evaluations.

For each affected observation identify:

- entry intersection
- holding-period intersection
- exit intersection
- current raw-price/censor/missing-data treatment
- exact missing entitlement/identity field needed to make the observation valid

Diagnostic only. Do not rewrite prior outcomes.

## Workstream E — direction-aware one-price / limit execution evidence

For the affected one-price/limit cases retain:

- buy vs sell direction
- intended decision timestamp
- intended order type / price assumption
- official reference/open/limit prices
- daily traded volume
- any actually available official opening-auction matched volume/allocation/quote evidence
- fill status: PROVEN / DISPROVEN / UNKNOWN

Hard rules:

- one price at lower limit is not universal no-fill evidence for a buy
- daily volume is not proof of allocation
- do not invent queue position, depth, latency, or capacity
- do not retroactively alter the old symmetric censor in this stage

## Workstream F — adjusted-return state machine

Implement only if required evidence is proven.

States must distinguish:

1. ordinary price return
2. cash receivable not yet paid
3. stock entitlement not yet delivered/saleable
4. subscription right requiring cash/deadline
5. suspension/no tradable price
6. old security converted into new security
7. unresolved action -> block observation

Fail closed on missing/conflicting terms.

## Readiness gates

Do not start a new model study unless `READINESS_V2.json` proves the selected study specification can be evaluated without fabricated outcomes.

Report separately:

- global 1,151-event term coverage
- delivery/payment-date coverage
- security-identity continuity coverage
- historical-trial impact coverage
- entry/exit observations still blocked by action terms
- observations still blocked by execution uncertainty
- first-seen/revision coverage
- whether a narrower frozen scope is valid for future research

Allowed statuses:

- `BLOCKED_DATA_READINESS`
- `PARTIAL_SCOPE_READY`
- `READY_FOR_PREREGISTERED_RESEARCH`

## Testing requirements

Add synthetic/offline tests for at least:

- mixed cash + stock entitlement
- stock dividend with delayed delivery
- paid subscription
- cash capital reduction
- no-cash capital reduction
- split/conversion identity transition
- suspension spanning an intended exit
- unknown payment/delivery date blocks reinvestment
- current security-master substitution rejected
- event-detail mismatch rejected
- conflicting official terms fail closed
- direction-aware lower-limit buy vs sell semantics
- daily volume not treated as fill proof
- prior 8,529 experiment history unchanged
- zero new model evaluations
- zero production authority

CI must remain offline and must not recollect live official data or launch model trials.

## Required deliverables

Create a versioned directory such as:

`research/codex_full_reset_20261023/data_foundation_v2_20261023/`

Include:

1. `PLAN_V2.json`
2. `EVENT_CLASSIFICATION.jsonl`
3. `ENTITLEMENT_LEDGER.jsonl`
4. `IDENTITY_TRANSITIONS.jsonl`
5. `HISTORICAL_IMPACT_MAP.jsonl`
6. `EXECUTION_EVIDENCE.jsonl`
7. `COVERAGE_V2.json`
8. `READINESS_V2.json`
9. `REPORT.md`
10. raw/receipt/hash manifests for new official-source collection
11. offline tests and one-command audit entrypoint

## Stop conditions

Stop and report instead of inventing evidence if:

- official detail coverage requires paid/private access
- payment/share-delivery timing cannot be proven
- historical identity continuity cannot be proven
- official schemas conflict without resolution
- order allocation/fill cannot be established
- readiness requires guessed adjustment factors/fills
- prior experiment history would need rewriting
- evidence hashes/trial accounting are incomplete

## Completion standard

A successful V2 may still remain `BLOCKED_DATA_READINESS`.

The valuable outcome is an auditable map of which historical observations are valid, which are blocked, why, and exactly what future preregistered study can be run safely.

**PRODUCTION MODEL CHANGES: NONE.**
