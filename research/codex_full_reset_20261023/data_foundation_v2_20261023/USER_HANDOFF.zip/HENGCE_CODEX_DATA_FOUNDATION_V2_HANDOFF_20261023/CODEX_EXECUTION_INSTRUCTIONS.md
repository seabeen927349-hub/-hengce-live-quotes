# CODEX EXECUTION INSTRUCTIONS

Use this checklist exactly.

## 1. Verify repository state

Repo:
`seabeen927349-hub/-hengce-live-quotes`

Branch:
`research/codex-full-reset-run-20261023`

Expected handoff commit:
`593652df3e414b223eea0d568299084cf5c85c52`

Do not use moving main as the research dataset.

## 2. Read repository-native task

Read:
`research/codex_full_reset_20261023/CODEX_DATA_FOUNDATION_V2_TASK.md`

This handoff ZIP is supplemental. The repository-native task is canonical if wording differs.

## 3. Freeze V2 plan BEFORE collection

Create and push `PLAN_V2.json` before new network collection.

The plan must define:
- source endpoints/document families
- finite request budget
- retry/spacing/timeout rules
- normalized schema
- stop conditions
- zero model-trial budget
- authority boundary

## 4. Execute V2 only

Do NOT:
- run a new model search
- retune Residual Reversal
- retune Beta-weighted Residual Reversal
- retune Skip5 H20
- rewrite old failed outcomes
- alter Q017/E2/M1 production code

## 5. Produce evidence + readiness

Required scientific output:
`READINESS_V2.json`

Allowed final statuses only:
- BLOCKED_DATA_READINESS
- PARTIAL_SCOPE_READY
- READY_FOR_PREREGISTERED_RESEARCH

## 6. Preserve auditability

Retain:
- raw bytes
- SHA256
- source URLs
- fetch timestamps
- failed validation receipts
- schema/version identifiers
- explicit UNKNOWN/CONFLICT cases

No guessed fills, factors, delivery dates, or historical publication times.

## 7. Stop for human review

After V2 deliverables, stop.
Do not launch a model-search batch automatically even if readiness passes.
A separate preregistered study must be authorized next.
