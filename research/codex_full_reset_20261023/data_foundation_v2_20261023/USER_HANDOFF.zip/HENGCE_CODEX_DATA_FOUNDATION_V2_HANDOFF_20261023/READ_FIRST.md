# READ FIRST — HENGCE Codex Data Foundation V2 Handoff

This package hands off the next HENGCE research stage to Codex.

## Repository

- Repo: `seabeen927349-hub/-hengce-live-quotes`
- Active research branch: `research/codex-full-reset-run-20261023`
- Current handoff head: `593652df3e414b223eea0d568299084cf5c85c52`
- Parent Data Foundation V1 head: `0c24f9795e36b52e28eafed186eee5591ec93353`
- Frozen corpus base: `05bf0e35fb6a88473fd4f947952ef1b6875d3f88`
- Issue: `#31 Codex Data Foundation V2: corporate-action entitlement + execution readiness`
- Parent research issue: `#29`
- Research PR: `#30 Draft: full-reset electronics research — no robust winner`

## First action for Codex

1. Checkout/fetch the repo and exact research branch.
2. Verify branch head is at least `593652df3e414b223eea0d568299084cf5c85c52`.
3. Read:
   - `research/codex_full_reset_20261023/CODEX_DATA_FOUNDATION_V2_TASK.md`
   - V1 data-foundation report and readiness files
   - Issue #31
4. Do NOT start a new model search.
5. Before any new network collection, commit and push a frozen machine-readable `PLAN_V2.json`.
6. New model-evaluation budget for V2 is **0**.

## Hard authority boundary

- research_only = true
- signal_authority = false
- ranking_authority = false
- capital_authority_twd = 0
- broker_order_execution = false
- production_promotion = false
- merge_authorized = false
- no write to main
- no Q017/E2/M1 production semantic change
- no live producer/schedule change

## Completion target

Produce Data Foundation V2 evidence and `READINESS_V2.json` with exactly one scientific status:

- `BLOCKED_DATA_READINESS`
- `PARTIAL_SCOPE_READY`
- `READY_FOR_PREREGISTERED_RESEARCH`

A valid result may remain blocked. Do not invent missing corporate-action or execution evidence.
