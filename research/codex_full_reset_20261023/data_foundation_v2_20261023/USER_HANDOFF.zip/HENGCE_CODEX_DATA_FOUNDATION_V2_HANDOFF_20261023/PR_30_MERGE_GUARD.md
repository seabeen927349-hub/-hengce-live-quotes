# PR #30 status and merge guard

PR:
`#30 Draft: full-reset electronics research — no robust winner`

Required state:
- KEEP OPEN
- KEEP DRAFT
- NOT MERGED as a trading model

Reason:
The research branch contains scientific evidence, failed studies, data-readiness work, and historical diagnostics. It does not authorize production promotion.

Production changes remain NONE.

Do not merge V2 into production or main merely because data-readiness improves.
Any future promotion requires a separate explicit human authorization after preregistered research and prospective shadow validation.
