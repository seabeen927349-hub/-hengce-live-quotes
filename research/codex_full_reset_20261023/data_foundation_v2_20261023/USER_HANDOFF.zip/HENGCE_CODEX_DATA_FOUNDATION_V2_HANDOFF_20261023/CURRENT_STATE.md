# CURRENT STATE

## Research outcome so far

The full-reset research did not establish a robust historical winner.

- Original full-reset result: `NO_ROBUST_WINNER`
- Cumulative model evaluations retained: **8,529**
- All 2023–2026 historical material is exposed research history, not pristine OOS.
- Production Q017/E2/M1 remains unchanged.

## Data Foundation V1

V1 was completed at:

`0c24f9795e36b52e28eafed186eee5591ec93353`

V1 used free official sources only and added **0 new model evaluations**.

Important V1 evidence:

- 3,686 official-source returned corporate-action events
- 1,151 exact PIT TWSE-listed electronics projected events
  - 1,119 ex-right/dividend events
  - 32 capital reductions
- 6189 on 2025-07-25:
  - cash 3.999732 per old share
  - 200 free shares / 1,000 old shares
  - raw discontinuity therefore cannot be interpreted as simple wealth loss
- 2364 on 2025-08-28:
  - 300 free shares / 1,000 old shares
  - zero cash
- 3090 on 2025-07-15:
  - official suspension evidence explains missing OHLC
- 2327 in Aug 2025:
  - official evidence supports 1,000 old shares -> 4,000 new shares
  - trading halt and later resumption
- 2025-04-07:
  - 26 prior one-price cases matched the official lower price limit exactly
  - one-price lower-limit does NOT prove a hypothetical buy could not fill
  - traded volume also does NOT prove the hypothetical order did fill

V1 readiness remained:

`BLOCKED_DATA_READINESS`

Reasons:

- CORPORATE_ACTION_TERMS_AND_DELIVERY_NOT_COMPLETE
- SECURITY_IDENTITY_CONTINUITY_NOT_COMPLETE
- ORIGINAL_PUBLICATION_AND_REVISION_HISTORY_UNPROVEN
- AUCTION_ALLOCATION_AND_FILL_EVIDENCE_UNAVAILABLE

## Important scientific constraint

Do not retroactively repair or reclassify the prior 8,529 model evaluations.

Any future changed corporate-action handling or execution handling is a **new registered experiment**, not a rescue of an old failed study.
