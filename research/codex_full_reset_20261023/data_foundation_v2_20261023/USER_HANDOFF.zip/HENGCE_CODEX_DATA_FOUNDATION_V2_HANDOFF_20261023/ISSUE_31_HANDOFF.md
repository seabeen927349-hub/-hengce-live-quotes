# GitHub Issue #31 — Codex Data Foundation V2

Title:
`Codex Data Foundation V2: corporate-action entitlement + execution readiness`

Repo:
`seabeen927349-hub/-hengce-live-quotes`

Working branch:
`research/codex-full-reset-run-20261023`

Registered task commit:
`593652df3e414b223eea0d568299084cf5c85c52`

Parent V1 head:
`0c24f9795e36b52e28eafed186eee5591ec93353`

Core contract:
- free official sources only
- zero new model evaluations
- no retroactive rescue of old studies
- no production/model authority
- produce READINESS_V2 before any new model search
