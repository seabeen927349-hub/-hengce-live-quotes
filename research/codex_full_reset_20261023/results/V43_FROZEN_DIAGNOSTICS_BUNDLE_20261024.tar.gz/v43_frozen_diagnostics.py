#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import io
import json
import math
import random
import statistics
import tarfile
import zipfile
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
# Byte-for-byte archived research evidence. Local fallback is only for standalone verification.
REPO_ARCHIVE = ROOT / 'research/codex_full_reset_20261023/archive/20261024/HENGCE_FINAL_RESEARCH_ARCHIVE_20261024.tar.gz'
LOCAL_ARCHIVE = Path('/mnt/data/HENGCE_FINAL_RESEARCH_ARCHIVE_20261024.tar.gz')
REPO_OUT_DIR = ROOT / 'research/codex_full_reset_20261023/results'
EXPECTED_ARTIFACT_SHA256 = 'b900fde5eee6d97ca24cce1e0d77b1977dc9103642d55c228b73ba6be2bb87e3'
EXPECTED_EVENTS_SHA256 = 'ed5b0c4caff523525ecafb303e04dc82bc07d7d2fe706733edf4ce0180ecfd6e'
EXPECTED_EVENT_COUNT = 30
COST = 0.012
SEED = 43
BOOT_REPS = 20000


def product(xs):
    z = 1.0
    for x in xs:
        z *= 1.0 + x
    return z - 1.0


def quantile(xs, q):
    a = sorted(xs)
    if not a:
        return None
    if len(a) == 1:
        return a[0]
    z = (len(a) - 1) * q
    i, j = int(math.floor(z)), int(math.ceil(z))
    if i == j:
        return a[i]
    return a[i] * (j - z) + a[j] * (z - i)


def summarize_nets(xs):
    return {
        'baskets': len(xs),
        'wins': sum(x > 0 for x in xs),
        'win_rate': sum(x > 0 for x in xs) / len(xs) if xs else None,
        'compounded_return': product(xs) if xs else None,
        'mean_net_return': statistics.mean(xs) if xs else None,
        'median_net_return': statistics.median(xs) if xs else None,
        'best_net_return': max(xs) if xs else None,
        'worst_net_return': min(xs) if xs else None,
    }


def moving_block_bootstrap(xs, block_len, reps=BOOT_REPS, seed=SEED):
    rng = random.Random(seed + block_len)
    n = len(xs)
    out = []
    blocks_needed = math.ceil(n / block_len)
    max_start = n - block_len
    for _ in range(reps):
        sample = []
        for _ in range(blocks_needed):
            s = rng.randint(0, max_start)
            sample.extend(xs[s:s + block_len])
        out.append(product(sample[:n]))
    return {
        'block_length_baskets': block_len,
        'repetitions': reps,
        'seed': seed + block_len,
        'probability_compounded_return_gt_0': sum(x > 0 for x in out) / reps,
        'probability_compounded_return_gt_1': sum(x > 1 for x in out) / reps,
        'q05_compounded_return': quantile(out, 0.05),
        'median_compounded_return': quantile(out, 0.50),
        'q95_compounded_return': quantile(out, 0.95),
    }


def load_archived_v43():
    archive = REPO_ARCHIVE if REPO_ARCHIVE.exists() else LOCAL_ARCHIVE
    with tarfile.open(archive, 'r:gz') as tf:
        member = next(m for m in tf.getmembers() if m.name.endswith('/artifacts/hengce-ranking-v43-expanding-regime-icir.zip'))
        artifact_bytes = tf.extractfile(member).read()
    artifact_sha = hashlib.sha256(artifact_bytes).hexdigest()
    if artifact_sha != EXPECTED_ARTIFACT_SHA256:
        raise SystemExit(f'V43 artifact hash drift: {artifact_sha}')
    with zipfile.ZipFile(io.BytesIO(artifact_bytes)) as zf:
        events_bytes = zf.read('ranking_v43_events.jsonl')
        result = json.loads(zf.read('ranking_v43_expanding_regime_icir_result.json'))
    events_sha = hashlib.sha256(events_bytes).hexdigest()
    if events_sha != EXPECTED_EVENTS_SHA256:
        raise SystemExit(f'V43 events hash drift: {events_sha}')
    events = [json.loads(line) for line in events_bytes.decode('utf-8').splitlines() if line.strip()]
    if len(events) != EXPECTED_EVENT_COUNT:
        raise SystemExit(f'V43 event count drift: {len(events)}')
    return artifact_sha, events_sha, events, result


def main():
    artifact_sha, events_sha, events, formal = load_archived_v43()
    rows = []
    for e in events:
        net = e['exposure'] * (e['gross_return'] - COST)
        rows.append({
            'signal_date': e['signal_date'],
            'exit_date': e['exit_date'],
            'year': e['year'],
            'regime': e['regime'],
            'net_return': net,
            'gross_return': e['gross_return'],
            'exposure': e['exposure'],
            'risk_multiplier': e['risk_multiplier'],
            'tickers': e['tickers'],
        })
    nets = [r['net_return'] for r in rows]
    baseline = product(nets)
    order = sorted(range(len(nets)), key=lambda i: nets[i], reverse=True)

    removal = {}
    for k in (1, 2, 3, 5):
        removed = set(order[:k])
        removal[str(k)] = {
            'compounded_return_after_removing_top_k': product([x for i, x in enumerate(nets) if i not in removed]),
            'removed_signal_dates': [rows[i]['signal_date'] for i in order[:k]],
        }

    loo = [product([x for j, x in enumerate(nets) if j != i]) for i in range(len(nets))]

    regimes = {}
    for regime in sorted(set(r['regime'] for r in rows)):
        regimes[regime] = summarize_nets([r['net_return'] for r in rows if r['regime'] == regime])
    years = {}
    for year in sorted(set(r['year'] for r in rows)):
        years[year] = summarize_nets([r['net_return'] for r in rows if r['year'] == year])

    max_loss_streak = 0
    cur = 0
    for x in nets:
        if x <= 0:
            cur += 1
            max_loss_streak = max(max_loss_streak, cur)
        else:
            cur = 0

    rolling = {}
    for k in (3, 5, 6, 10):
        vals = [product(nets[i:i + k]) for i in range(len(nets) - k + 1)]
        rolling[str(k)] = {
            'windows': len(vals),
            'positive_windows': sum(x > 0 for x in vals),
            'positive_fraction': sum(x > 0 for x in vals) / len(vals),
            'worst_compounded_return': min(vals),
            'best_compounded_return': max(vals),
        }

    ticker_count = Counter()
    ticker_weight = defaultdict(float)
    ticker_max_weight = defaultdict(float)
    for e in events:
        for t, w in zip(e['tickers'], e['weights']):
            ticker_count[t] += 1
            ticker_weight[t] += w
            ticker_max_weight[t] = max(ticker_max_weight[t], w)
    ranked_weight = sorted(ticker_weight, key=lambda t: ticker_weight[t], reverse=True)
    ticker_diag = {
        'unique_tickers': len(ticker_count),
        'total_basket_weight_mass': sum(ticker_weight.values()),
        'top_5_ticker_weight_share': sum(ticker_weight[t] for t in ranked_weight[:5]) / sum(ticker_weight.values()),
        'top_10_ticker_weight_share': sum(ticker_weight[t] for t in ranked_weight[:10]) / sum(ticker_weight.values()),
        'most_frequent': [
            {'ticker': t, 'basket_occurrences': ticker_count[t], 'cumulative_weight': ticker_weight[t], 'max_single_basket_weight': ticker_max_weight[t]}
            for t in sorted(ticker_count, key=lambda t: (ticker_count[t], ticker_weight[t]), reverse=True)[:10]
        ],
    }

    factor_names = list(events[0]['factor_weights'])
    factor_diag = {}
    for f in factor_names:
        xs = [e['factor_weights'][f] for e in events]
        factor_diag[f] = {
            'mean': statistics.mean(xs),
            'stdev': statistics.stdev(xs),
            'min': min(xs),
            'max': max(xs),
            'range': max(xs) - min(xs),
        }

    scaled = []
    for r in rows:
        if r['risk_multiplier'] < 1 - 1e-12:
            scaled.append({k: r[k] for k in ('signal_date', 'exit_date', 'regime', 'net_return', 'exposure', 'risk_multiplier', 'tickers')})

    top = sorted(rows, key=lambda r: r['net_return'], reverse=True)[:5]
    bottom = sorted(rows, key=lambda r: r['net_return'])[:5]

    boot = {str(b): moving_block_bootstrap(nets, b) for b in (1, 3, 5)}

    payload = {
        'status': 'V43_FROZEN_DIAGNOSTICS_COMPLETE',
        'diagnostic_version': 'V43_FROZEN_DIAGNOSTICS_V1',
        'new_model_evaluations': 0,
        'model_change': False,
        'parameter_search': False,
        'source': {
            'archived_v43_artifact_sha256': artifact_sha,
            'archived_v43_events_sha256': events_sha,
            'event_count': len(events),
            'formal_status': formal['status'],
        },
        'cost_assumption': COST,
        'baseline': {
            'compounded_return': baseline,
            'formal_compounded_return': formal['combined']['0.012']['compounded_return'],
            'formal_max_drawdown': formal['combined']['0.012']['max_drawdown'],
            'formal_remove_best_basket_return': formal['combined']['0.012']['remove_best_basket_return'],
            'wins': sum(x > 0 for x in nets),
            'win_rate': sum(x > 0 for x in nets) / len(nets),
            'max_consecutive_nonpositive_baskets': max_loss_streak,
        },
        'best_basket_removal_stress': removal,
        'leave_one_out': {
            'all_leave_one_out_compounded_returns_positive': all(x > 0 for x in loo),
            'minimum_compounded_return': min(loo),
            'maximum_compounded_return': max(loo),
        },
        'regime_attribution': regimes,
        'year_attribution': years,
        'rolling_sequence_stress': rolling,
        'ticker_concentration': ticker_diag,
        'factor_weight_stability': factor_diag,
        'risk_overlay_scaled_baskets': scaled,
        'top_5_baskets': top,
        'bottom_5_baskets': bottom,
        'historical_resampling_diagnostic': boot,
        'interpretation': {
            'positive': 'V43 remains strongly positive after removing several best baskets, all leave-one-out histories remain positive, factor weights stay in a narrow range, and name reuse is dispersed across 71 tickers.',
            'risk': 'Historical alpha is materially stronger in STRONG breadth than WEAK breadth; 2026 also contains the single largest basket. These are concentration/conditioning risks to validate prospectively, not reasons to retune V43.',
            'bootstrap_caveat': 'Moving-block resampling reuses exposed historical baskets and assumes some historical representativeness. It is a fragility diagnostic only, not prospective or production evidence.',
        },
        'authority': {
            'research_only': True,
            'capital_authority_twd': 0,
            'broker_order_execution': False,
            'production_promotion': False,
            'merge_authorized': False,
            'main_write': False,
            'q017_production_change': False,
            'e2_production_change': False,
            'm1_production_change': False,
            'pr_30_merge': False,
        },
    }
    if abs(payload['baseline']['compounded_return'] - payload['baseline']['formal_compounded_return']) > 1e-12:
        raise SystemExit('formal 1.2% compounded-return parity failed')

    out_dir = REPO_OUT_DIR if REPO_ARCHIVE.exists() else Path('/mnt/data')
    out_dir.mkdir(parents=True, exist_ok=True)
    out_json = out_dir / 'V43_FROZEN_DIAGNOSTICS_20261024.json'
    out_json.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

    md = []
    md.append('# HENGCE V43 Frozen Diagnostics — 2026-10-24')
    md.append('')
    md.append('This is a **validation-only** diagnostic on the byte-for-byte archived V43 artifact. It performs **zero new model evaluations**, no tuning, and no production promotion.')
    md.append('')
    md.append('## Source integrity')
    md.append(f'- V43 artifact SHA-256: `{artifact_sha}`')
    md.append(f'- V43 events SHA-256: `{events_sha}`')
    md.append(f'- Frozen basket count: `{len(events)}`')
    md.append('')
    md.append('## 1.2% historical basket diagnostics')
    md.append(f'- Baseline compounded return: **{baseline*100:.2f}%**')
    md.append(f'- Formal max drawdown: **{formal["combined"]["0.012"]["max_drawdown"]*100:.2f}%**')
    md.append(f'- Win rate: **{sum(x>0 for x in nets)/len(nets)*100:.1f}%** ({sum(x>0 for x in nets)}/{len(nets)})')
    md.append(f'- Remove best basket: **{removal["1"]["compounded_return_after_removing_top_k"]*100:.2f}%**')
    md.append(f'- Remove top 2 baskets: **{removal["2"]["compounded_return_after_removing_top_k"]*100:.2f}%**')
    md.append(f'- Remove top 3 baskets: **{removal["3"]["compounded_return_after_removing_top_k"]*100:.2f}%**')
    md.append(f'- Remove top 5 baskets: **{removal["5"]["compounded_return_after_removing_top_k"]*100:.2f}%**')
    md.append(f'- All 30 leave-one-out histories positive: **{all(x>0 for x in loo)}**')
    md.append(f'- Max consecutive non-positive baskets: **{max_loss_streak}**')
    md.append('')
    md.append('## Regime attribution')
    for g in ('STRONG','WEAK'):
        x=regimes[g]
        md.append(f'- {g}: {x["baskets"]} baskets, win {x["win_rate"]*100:.1f}%, compounded **{x["compounded_return"]*100:.2f}%**, mean basket {x["mean_net_return"]*100:.2f}%')
    md.append('')
    md.append('The key caution is regime dependence: STRONG breadth contributes much more historical alpha than WEAK breadth. This is a prospective validation target, **not** a tuning instruction.')
    md.append('')
    md.append('## Sequence stress')
    for k in (3,5,6,10):
        x=rolling[str(k)]
        md.append(f'- Rolling {k} baskets: worst **{x["worst_compounded_return"]*100:.2f}%**, positive {x["positive_windows"]}/{x["windows"]} ({x["positive_fraction"]*100:.1f}%)')
    md.append('')
    md.append('## Name concentration')
    md.append(f'- Unique tickers across 90 basket slots: **{ticker_diag["unique_tickers"]}**')
    md.append(f'- Top 5 names by cumulative basket weight: **{ticker_diag["top_5_ticker_weight_share"]*100:.2f}%** of total weight mass')
    md.append(f'- Top 10 names: **{ticker_diag["top_10_ticker_weight_share"]*100:.2f}%**')
    mf=ticker_diag['most_frequent'][0]
    md.append(f'- Most frequent ticker: `{mf["ticker"]}` in **{mf["basket_occurrences"]}/30** baskets')
    md.append('')
    md.append('## Factor-weight stability')
    for f,x in factor_diag.items():
        md.append(f'- `{f}`: mean {x["mean"]:.4f}, min {x["min"]:.4f}, max {x["max"]:.4f}, stdev {x["stdev"]:.4f}')
    md.append('')
    md.append('## Risk overlay')
    md.append(f'- V30 fragile-strong risk scaling activated in **{len(scaled)}/30** baskets.')
    if scaled:
        md.append(f'- Those scaled baskets had 1.2% net returns: ' + ', '.join(f'{x["signal_date"]}: {x["net_return"]*100:.2f}%' for x in scaled))
    md.append('')
    md.append('## Historical resampling diagnostic')
    for b in (1,3,5):
        x=boot[str(b)]
        md.append(f'- Block {b}: P(return > 0) {x["probability_compounded_return_gt_0"]*100:.2f}%, 5th percentile {x["q05_compounded_return"]*100:.2f}%')
    md.append('')
    md.append('These resamples reuse exposed history. They are **not prospective evidence** and do not authorize production.')
    md.append('')
    md.append('## Research conclusion')
    md.append('V43 survives materially stronger concentration and sequence diagnostics than the original remove-best check. The principal unresolved issue is not historical fragility but **regime dependence and genuine post-lock validation**. Therefore the correct next research step is to observe frozen V43 prospectively; no local retuning or V45 expansion is justified by this diagnostic.')
    md.append('')
    md.append('Authority remains research-only: capital 0; broker orders false; production promotion false; main/Q017/E2/M1 unchanged; PR #30 unmerged.')
    out_md = out_dir / 'V43_FROZEN_DIAGNOSTICS_20261024.md'
    out_md.write_text('\n'.join(md)+'\n',encoding='utf-8')
    print(json.dumps({'json':str(out_json),'md':str(out_md),'baseline':baseline,'remove_top5':removal['5']['compounded_return_after_removing_top_k'],'regimes':regimes},ensure_ascii=False,indent=2))

if __name__ == '__main__':
    main()
