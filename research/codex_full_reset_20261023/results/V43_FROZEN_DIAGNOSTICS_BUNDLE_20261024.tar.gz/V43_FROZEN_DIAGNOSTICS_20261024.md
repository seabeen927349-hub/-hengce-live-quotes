# HENGCE V43 Frozen Diagnostics — 2026-10-24

This is a **validation-only** diagnostic on the byte-for-byte archived V43 artifact. It performs **zero new model evaluations**, no tuning, and no production promotion.

## Source integrity
- V43 artifact SHA-256: `b900fde5eee6d97ca24cce1e0d77b1977dc9103642d55c228b73ba6be2bb87e3`
- V43 events SHA-256: `ed5b0c4caff523525ecafb303e04dc82bc07d7d2fe706733edf4ce0180ecfd6e`
- Frozen basket count: `30`

## 1.2% historical basket diagnostics
- Baseline compounded return: **342.65%**
- Formal max drawdown: **-17.67%**
- Win rate: **66.7%** (20/30)
- Remove best basket: **193.12%**
- Remove top 2 baskets: **132.83%**
- Remove top 3 baskets: **96.38%**
- Remove top 5 baskets: **54.21%**
- All 30 leave-one-out histories positive: **True**
- Max consecutive non-positive baskets: **2**

## Regime attribution
- STRONG: 15 baskets, win 73.3%, compounded **228.22%**, mean basket 8.95%
- WEAK: 15 baskets, win 60.0%, compounded **34.86%**, mean basket 2.24%

The key caution is regime dependence: STRONG breadth contributes much more historical alpha than WEAK breadth. This is a prospective validation target, **not** a tuning instruction.

## Sequence stress
- Rolling 3 baskets: worst **-10.55%**, positive 23/28 (82.1%)
- Rolling 5 baskets: worst **-10.23%**, positive 23/26 (88.5%)
- Rolling 6 baskets: worst **-6.54%**, positive 20/25 (80.0%)
- Rolling 10 baskets: worst **1.42%**, positive 21/21 (100.0%)

## Name concentration
- Unique tickers across 90 basket slots: **71**
- Top 5 names by cumulative basket weight: **19.66%** of total weight mass
- Top 10 names: **32.03%**
- Most frequent ticker: `2454` in **4/30** baskets

## Factor-weight stability
- `resid_rev`: mean 0.1957, min 0.1800, max 0.2300, stdev 0.0130
- `mom20`: mean 0.2576, min 0.2439, max 0.2773, stdev 0.0068
- `skip5_60`: mean 0.2825, min 0.2700, max 0.3030, stdev 0.0130
- `liquidity`: mean 0.0639, min 0.0450, max 0.0799, stdev 0.0114
- `lowvol`: mean 0.2004, min 0.1800, max 0.2196, stdev 0.0120

## Risk overlay
- V30 fragile-strong risk scaling activated in **4/30** baskets.
- Those scaled baskets had 1.2% net returns: 2025-08-22: 12.56%, 2025-09-23: 8.84%, 2026-02-03: -0.33%, 2026-06-23: -5.46%

## Historical resampling diagnostic
- Block 1: P(return > 0) 99.97%, 5th percentile 96.27%
- Block 3: P(return > 0) 99.94%, 5th percentile 93.54%
- Block 5: P(return > 0) 99.93%, 5th percentile 102.50%

These resamples reuse exposed history. They are **not prospective evidence** and do not authorize production.

## Research conclusion
V43 survives materially stronger concentration and sequence diagnostics than the original remove-best check. The principal unresolved issue is not historical fragility but **regime dependence and genuine post-lock validation**. Therefore the correct next research step is to observe frozen V43 prospectively; no local retuning or V45 expansion is justified by this diagnostic.

Authority remains research-only: capital 0; broker orders false; production promotion false; main/Q017/E2/M1 unchanged; PR #30 unmerged.
